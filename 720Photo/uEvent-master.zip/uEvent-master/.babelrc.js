module.exports = {
    presets: [
        [
            '@babel/env',
            {
                loose  : true,
                modules: false
            }
        ]
    ]
};
